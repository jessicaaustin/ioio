package ioio.lib.api;

public interface Closeable {
	void close();
}
